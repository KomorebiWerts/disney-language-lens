(function () {
  "use strict";
  // Upgrade bridge for browsers that still have the earlier unpacked manifest
  // in memory. On the next Disney page refresh it reloads the extension once,
  // then the 1.0 manifest takes over.
  try {
    if (chrome.runtime.getManifest().version !== "1.1.0") chrome.runtime.reload();
  } catch (_) {}
})();
